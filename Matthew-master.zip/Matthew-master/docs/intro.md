---
sidebar_position: 1
hide_table_of_contents: true
---

# Tutorial Intro

Let's discover **Docusaurus in less than 5 minutes**.

## Getting Started

Let's get started